<div class="navbar navbar-inverse navbar-fixed-bottom">
   <div class="container">
      <p class="navbar-text pull-left">&#169; CI3+AJAX+BOOTSTRAP (DASAR CRUD) by SMAKKERZ &copy; <?php echo date("Y"); ?> &bullet; </p>
      <a href="https://github.com/smakkerz" class="navbar-btn btn-primary btn pull-right">GITHUB</a>
      <a href="http://smakkerz.blogspot.co.id/" class="navbar-btn btn-success btn pull-right">BLOGGER</a>
   </div>
</div>