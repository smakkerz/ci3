<div class="wrapper">
  <div class="content-edit">
    <div class="container well">
      <h3>EDIT DATA SISWA <span class="close-form">X</span></h3>
  <hr>
        <form class="form-horizontal" name="form1" method="post" action="sia/u_siswa">
          <div class="form-group">
              <label class="col-sm-2 control-label">NIS</label> 
              <div class="col-sm-3">
               <input class="form-control" name="nis" type="text" placeholder="Nomor Induk Siswa" readonly id="result-nis" required> 
              </div>
              <label class="col-sm-2 control-label">JENIS KELAMIN</label> 
              <div class="col-sm-3">
                <input type="text" name="kelamin" id="result-kelamin" readonly checked> 
              </div> 
          </div>
          <div class="form-group">
              <label class="col-sm-2 control-label">NAMA SISWA</label> 
              <div class="col-sm-3">
               <input class="form-control" name="nama" id="result-nama" type="text" placeholder="Nama Siswa" required> 
              </div> 
              <label class="col-sm-2 control-label">ALAMAT</label>
              <div class="col-sm-3">
                <textarea class="form-control" name="alamat" id="result-alamat" rows="2"></textarea>
              </div>
          </div>
          <!-- <div class="form-group"> 
              <label class="col-sm-2 control-label">FOTO </label> 
                <div class="col-sm-5">
                  <input type="file" class="btn btn-danger btn-sm" readonly accept="image/JPEG">Ukuran Gambar/Foto maksimal 1,5 Mb
                </div> 
          </div> -->
          <div class="form-group"> 
              <label class="col-sm-2 control-label">SKS</label>
                <div class="col-sm-3">
                    <input type="number" class="form-control" id="result-sks" placeholder="Jumlah SKS" name="sks" required> 
                </div> 
                  <button type="submit" class="btn btn-danger" name="ubah_s">
                    SIMPAN</button>
            </div>
        </form>
      </div>
    </div>
</div>