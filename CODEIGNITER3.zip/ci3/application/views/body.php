<div class="container">
	<div class="table-responsive">
		<table class="table">
			<tr>
				<th>NIS</th>
				<th>NAMA SISWA</th>
				<th>JENIS KELAMIN</th>
				<th>ALAMAT</th>
				<th>FOTO</th>
				<th>SKS</th>
				<th>OPSI</th>
			</tr>
	<?php 
		foreach ($rows as $row ) {
			$nis = $row->nis;
			$nama = $row->nama;
			$kelamin = $row->j_k;
			$alamat = $row->alamat;
			$sks = $row->sks;
			?>
			<tr>
				<td><?php echo $nis; ?></td>
				<td><?php echo $nama; ?></td>
				<td><?php echo $kelamin; ?></td>
				<td><?php echo $alamat; ?></td>
				<td><img width="130px" src="<?php echo base_url();?>foto/<? echo $row->foto; ?>"></td>
				<td><?php echo $sks; ?></td>
				<td>
				<?php echo "<a href='#' class='control' data-set='edit' data-nis='$nis' data-nama='$nama' data-alamat='$alamat' data-kelamin='$kelamin' data-sks='$sks' title='$nis' "; ?> >Ubah</a> &bullet;
				<a href="sia/d_siswa/<?php echo $row->nis; ?>" onclick="return confirm('Anda yakin ?');">Hapus</a></td>
			</tr>
			<?php
			}
			?>
		</table>
	</div>
</div>