<div class="wrapper">
  <div class="content-form">
    <div class="container">
      <div class="well">
        <h3> TAMBAH DATA SISWA <span class="close-form">X</span> </h3>
    <hr>
          <form class="form-horizontal" method="post" action="sia/i_siswa">
            <div class="form-group">
              <label class="col-sm-2 control-label">NIS</label> 
              <div class="col-sm-3">
               <input class="form-control" name="nis" type="text" placeholder="Nomor Induk Siswa" required> 
              </div> 
              <label class="col-sm-2 control-label">JENIS KELAMIN</label> 
              <div class="col-sm-3">
                <input type="radio" name="kelamin" value="Pria">Pria
                <input type="radio" name="kelamin" value="Wanita">Wanita
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label">NAMA SISWA</label> 
              <div class="col-sm-3">
               <input class="form-control" name="nama" id="pid-nama" type="text" placeholder="Nama Siswa" required> 
              </div> 
              <label class="col-sm-2 control-label">ALAMAT</label>
              <div class="col-sm-3">
                <textarea class="form-control" name="alamat" rows="2"></textarea>
              </div>
            </div>
           <!--<div class="form-group"> 
              //<label class="col-sm-2 control-label">FOTO </label> 
                //<div class="col-sm-5">
                  //<input type="file" class="btn btn-danger btn-sm" accept="image/JPEG" name="foto">Ukuran Gambar/Foto maksimal 1,5 Mb
                //</div> 
          //</div> -->
            <div class="form-group"> 
              <label class="col-sm-2 control-label">SKS</label>
                <div class="col-sm-3">
                    <input type="number" class="form-control" placeholder="Jumlah SKS" name="sks" required> 
                </div> 
                  <button type="submit" class="btn btn-primary" name="tambah_s">
                    TAMBAH</button>
            </div>
          </form>
      </div>
    </div>
  </div>
</div>