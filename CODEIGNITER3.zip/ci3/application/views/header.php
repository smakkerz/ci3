<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>CI3+AJAX Bootstrap</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/css/bootstrap.css');?>">
    <script type="text/javascript" src="<?php echo base_url('asset/js/jquery.min.js');?>"></script> 
    <script type="text/javascript" src="<?php echo base_url('asset/js/bootstrap.js');?>"></script> 
        <script type="text/javascript" src="<?php echo base_url('asset/js/data_java.js');?>"></script> 
</head>
<body>
<div class="container-fluid">
    <nav class="navbar navbar-fixed-top">
	     <div class="row" style="background: -webkit-linear-gradient(38deg, #88e, #09a); background-color: #88c; ">
		    <h3 style="margin: 2px 2px; padding: 10px 20px ;color: #fff; ">
			    BELAJAR CodeIgniter 3+AJAX BOOTSTRAP 	 
			    <a href="#" class="control" data-set="tambah">
					<div class="label label-primary" style="font-size:15px;">Tambah Siswa</div>
				</a>
				      <!-- <i class="pull-right">

				      </i> -->
		    </h3>
	     </div>
    </nav>
</div>