<?php
	class Hello extends CI_Controller
	{
		public function index()
		{
			//memuat model di Haidunia_m
			$this->load->model('Haidunia_m');
			//menangkap objek dari kelas Haidunai_m yang telah dimuat di model
			$model = $this->Haidunia_m;
			//mengambil data dari model
			$s = $model->str;
			$si = $model->save;
			//membuat data yang dikirim secara array
			$data = ['teks'=>$s, 'teks_baru'=>$si];
			//memuat view dengan mengirim data ke view
			$this->load->view('haidunia', $data);
		}
	}