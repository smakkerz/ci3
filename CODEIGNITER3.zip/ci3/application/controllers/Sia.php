<?php
error_reporting(1);
	class Sia extends CI_Controller
	{
	public $model = NULL;
	public function __construct() {
		parent::__construct();
		$this->load->model('M_Sia'); //memuat model
		$this->model = $this->M_Sia; //memuat kelas model
		$this->load->database(); // untuk memuat database
		$this->load->helper('url', 'file'); //untuk memanggil helper
	}	
		public function index() //memuat data di function index
		{
			$this->load->view('header'); //memuat header
			$this->i_siswa(); //memuat function tambah data siswa
			$this->u_siswa(); //memuat function ubah data siswa
			$this->r_siswa(); //memuat function tampil data siswa
			$this->load->view('footer');

		}
		public function r_siswa() //memuat function tampil data siswa
		{
			$rows = $this->model->r_siswa(); //mengolah dari function model r_siswa
			
			$this->load->view('body', ['rows' => $rows]); //memuat ke view body
		}
		public function i_siswa() //memuat function tambah data siswa
		{
			if (isset($_POST['tambah_s'])) {
				$this->model->nis = $_POST['nis'];
				$this->model->nama = $_POST['nama'];
				$this->model->foto = '50.png';
				$this->model->j_kelamin = $_POST['kelamin'];
				$this->model->alamat = $_POST['alamat'];
				$this->model->sks = $_POST['sks'];

				$this->model->i_siswa(); //mengolah dari function model i_siswa
				redirect('sia'); //mengarahkan ke sia
			} else {
				$this->load->view('insert', ['model'=>$this->model]); //memuat ke view insert
			}
		}
		public function u_siswa($nis) //memuat function ubah data siswa
		{
			if (isset($_POST['ubah_s'])) {
				$nis = $this->model->nis = $_POST['nis'];
				$this->model->nama = $_POST['nama'];
				$this->model->j_kelamin = $_POST['kelamin'];
				$this->model->alamat = $_POST['alamat'];
				$this->model->sks = $_POST['sks'];

				$this->model->u_siswa($nis); //mengolah dari function model u_siswa
				redirect('sia'); //mengarahkan ke sia
			} else {
				$qry = $this->db->query("SELECT*FROM siswa WHERE nis='$nis'");
				//if ($qry->num_rows() == 0) exit(1)
				$row = $qry->row();
				$this->model->nis = $row->nis;
				$this->model->nama = $row->nama;
				$this->model->j_kelamin = $row->j_k;
				$this->model->alamat = $row->alamat;
				$this->model->sks = $row->sks;

				$this->load->view('update', ['model'=>$this->model]); //memuat ke view update
			}
		}
		public function d_siswa($nis) //memuat function hapus data siswa
		{
			$this->model->nis = $nis; //memuat id nis yang akan dihapus
			$this->model->d_siswa(); //menghapus tabel yang berisi data nis
			redirect('sia'); //mengarahkan ke sia
		}
	}