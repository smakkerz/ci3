<?php
class M_Sia extends CI_Model
{
	public function __construct()
	{
		$this->load->database(); //Memuat library database
	}
	public function i_siswa() {
		$data = [
		'nis'=> $this->nis,
		'nama'=> $this->nama,
		'foto'=> $this->foto,
		'j_k'=> $this->j_kelamin,
		'alamat'=> $this->alamat,
		'sks'=> $this->sks ];
		$sql = $this->db->insert_string('siswa', $data);
		$this->db->query($sql);
	}
	public function r_siswa() { //fungsi untuk menampilkan data siswa r_siswa = read siswa
		$sql = "SELECT*FROM siswa ORDER BY nis";
		$query = $this->db->query($sql);
		return $query->result();
	}
	public function u_siswa($nis) { //fungsi untuk memperbarui data siswa u_siswa = update siswa
		$data = [
		'nama'=> $this->nama,
		'j_k'=> $this->j_kelamin,
		'alamat'=> $this->alamat,
		'sks'=> $this->sks ];
		$where = "nis = '$nis'";
		$sql = $this->db->update_string('siswa', $data, $where);
		$this->db->query($sql);
	}
	public function d_siswa() { //fungsi untuk menghapus data siswa d_siswa = delete siswa
		$sql = sprintf("DELETE FROM siswa WHERE nis=%d",
			$this->nis );
		$this->db->query($sql);
	}
}