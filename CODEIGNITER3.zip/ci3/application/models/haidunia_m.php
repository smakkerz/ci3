<?php
class haidunia_m extends CI_Model {
	public $str = 'Selamat datang di CodeIgniter!';
}