$(function(){
   $('.control').on('click', function(){
  // mengambil isi element data-set dari class control untuk mengetahui proses yang akan di lakukan
  $set = $(this).attr('data-set');

  // jika isi set adalah tambah atau edit maka yang di animasi adalam form
  if($set == 'tambah' ){
   // mengambil isi element data-url dari class control

   // buat motion buka tutup
   $('.content-form, .content-edit').fadeOut('slow');
   setTimeout(function(){ $('.content-form').fadeIn('slow') }, 800);

   // ganti isi attribute action pada class form dengan url hasil dari element data-url pada class control

  // tapi jika isi set adalah lihat maka yang di animasi adalah eddit
  } else if($set == 'edit'){
   $('.content-form, .content-edit').slideUp('slow');
   setTimeout(function(){ $('.content-edit').slideDown('slow') }, 900);
  }

  if($set == 'tambah'){
   // kosongkan input, dan textarea
   $('#nama, #alamat').val('');

  }else if($set == 'edit'){
   // ambil isi attribute data-nama dan data-alamat pada class control
   $nis   = $(this).attr('data-nis');
   $nama   = $(this).attr('data-nama');
   $alamat = $(this).attr('data-alamat');
   $kelamin   = $(this).attr('data-kelamin');
   $sks     = $(this).attr('data-sks');

   // kemudian tempelkan di id;
   
   $('.content-edit #result-nis').val($nis);
   $('.content-edit #result-nama').val($nama);
   $('.content-edit #result-alamat').val($alamat);
   $('.content-edit #result-kelamin').val($kelamin);
   $('.content-edit #result-sks').val($sks);
  }
 });

 // menutup form atau view
 $('.close-form').on('click', function(){
  $('.content-form, .content-edit').fadeOut('slow');
 });
});